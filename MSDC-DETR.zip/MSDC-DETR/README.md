# MSDC-DETR: UAV Object Detection Enhanced by Multi-Scale Deformable Convolution

## 项目简介



MSDC-DETR是一种针对无人机（UAV）图像目标检测的创新模型。该模型结合了多尺度可变形卷积（MSDC）和自适应融合注意力模块（AFAM），旨在提高复杂背景下小物体的检测性能。通过动态调整卷积核的形状和大小，MSDC-DETR能够更好地适应不同目标的几何变化，从而有效提升目标检测的准确性和鲁棒性。

## 主要特点

- **多尺度可变形卷积**：MSDC模块动态调整卷积核，以增强对不同尺寸和形状目标的适应能力。
- **自适应融合注意力模块**：AFAM通过整合多尺度特征，改善模型对小物体的检测能力。
- **高性能**：在VisDrone和UAVDT数据集上，MSDC-DETR在mAP和其他评估指标上超越了现有的最先进方法。



## 安装与使用

请参考`requirements.txt`文件以安装所需的依赖项。您可以使用以下命令创建虚拟环境并安装依赖：

bash

复制

```python
pip install -r requirements.txt
```

## 数据集

本模型在以下数据集上进行训练和评估：

- VisDrone    https://github.com/VisDrone/VisDrone-Dataset
- UAVDT        https://github.com/dataset-ninja/uavdt

请确保您遵循相应数据集的使用条款。

## 贡献

欢迎任何形式的贡献！如果您有建议、问题或想要提交代码，请随时打开问题或提交拉取请求。